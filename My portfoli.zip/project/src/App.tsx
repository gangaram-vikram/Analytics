import React from 'react';
import { Github, Linkedin, Mail, FileText, ChevronDown, Database, LineChart, Brain, Code } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 to-purple-900 text-white">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80"
            alt="Data Analytics Background"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative z-10 text-center px-4">
          <img 
            src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&q=80"
            alt="Profile"
            className="w-32 h-32 rounded-full mx-auto mb-8 border-4 border-white shadow-xl"
          />
          <h1 className="text-5xl font-bold mb-4">Vikram G</h1>
          <p className="text-xl mb-4">Data Analyst</p>
          <p className="text-lg mb-8">📱 +91 8008036443 | ✉️ gangaramvikramvicky@gmail.com</p>
          <div className="flex justify-center gap-6 mb-8">
            <a href="https://github.com/gangaram-vikram" target="_blank" rel="noopener noreferrer" className="hover:text-blue-300 transition-colors">
              <Github size={24} />
            </a>
            <a href="https://linkedin.com/in/vikram" target="_blank" rel="noopener noreferrer" className="hover:text-blue-300 transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="mailto:gangaramvikramvicky@gmail.com" className="hover:text-blue-300 transition-colors">
              <Mail size={24} />
            </a>
          </div>
          <p className="text-sm mb-12 italic">"Create data-related content in Linkedin for around 14k+ followers"</p>
          <ChevronDown size={32} className="mx-auto animate-bounce" />
        </div>
      </header>

      {/* Skills Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-16">Core Competencies</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <Database className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="text-xl font-semibold mb-2">Data Management</h3>
              <p className="text-gray-600">Power BI, SQL, Python</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <LineChart className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="text-xl font-semibold mb-2">Data Visualization</h3>
              <p className="text-gray-600">Power BI, Advanced Excel</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <Brain className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="text-xl font-semibold mb-2">Data ETL Process</h3>
              <p className="text-gray-600">Power BI, Python</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg text-center">
              <Code className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="text-xl font-semibold mb-2">Programming</h3>
              <p className="text-gray-600">MySQL, Python, SQL</p>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20 px-4 bg-gray-100">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-16">Featured Projects</h2>
          <div className="space-y-8">
            <div className="bg-white rounded-lg overflow-hidden shadow-lg">
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Hospitality Analysis - Hotel Chain Business</h3>
                <p className="text-gray-600 mb-4">
                  Atliq Grands noticed a loss in market shares and revenue over a few months. Created a dashboard in Power BI using three months of data, helping the Revenue team gain insights about revenue trends, leading to a 20% recovery in revenue and market share.
                </p>
                <div className="flex gap-4">
                  <a href="#" className="text-blue-600 hover:text-blue-800 font-medium">GitHub Repo</a>
                  <a href="#" className="text-blue-600 hover:text-blue-800 font-medium">Live Dashboard</a>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-lg">
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Atliq Telecom 5G Analysis</h3>
                <p className="text-gray-600 mb-4">
                  Developed a Power BI dashboard analyzing weekly business KPIs including Revenue, Average revenue per user, and active users. Identified potential pitfalls enabling a 30% market share recovery within 3 months.
                </p>
                <div className="flex gap-4">
                  <a href="#" className="text-blue-600 hover:text-blue-800 font-medium">GitHub Repo</a>
                  <a href="#" className="text-blue-600 hover:text-blue-800 font-medium">Live Dashboard</a>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-lg">
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Supply Chain Data Analysis</h3>
                <p className="text-gray-600 mb-4">
                  Built a Power BI dashboard covering different KPIs (on-time delivery, in-full delivery, and OTIF%) to track business service levels at AtliQ Mart. Saved 20% of the investment in expansion with this analysis.
                </p>
                <div className="flex gap-4">
                  <a href="#" className="text-blue-600 hover:text-blue-800 font-medium">GitHub Repo</a>
                  <a href="#" className="text-blue-600 hover:text-blue-800 font-medium">Live Dashboard</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-16">Professional Experience</h2>
          <div className="space-y-12">
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Front Office Executive</h3>
                <p className="text-gray-600 mb-2">Suruchi cafe llp, Shadnagar • Sep 2021 - Present</p>
                <ul className="list-disc list-inside text-gray-600 space-y-2">
                  <li>Greeting Visitors: Welcoming clients, guests, and customers warmly and professionally</li>
                  <li>Managing Communication: Answering and directing phone calls, emails, and inquiries</li>
                  <li>Scheduling and Coordination: Managing appointments, meeting rooms, and calendars</li>
                  <li>Administrative Support: Handling paperwork, maintaining records, and providing clerical assistance</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education & Certifications */}
      <section className="py-20 px-4 bg-gray-100">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-16">Education & Certifications</h2>
          <div className="space-y-8">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-2">B.Com (Bachelors of Commerce)</h3>
              <p className="text-gray-600">Bharathi Degree College, Warangal, India • June 2021</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Certifications & Achievements</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Participating in Code Basics Resume Project Challenge (Nov 2024)</li>
                <li>Codebasics Certified Power BI Developer</li>
                <li>Codebasics Certified Python For Data Analytics</li>
                <li>Codebasics Certified SQL for Data Professionals</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Other Activities</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Loved reading the "Storytelling with data" Book by Cole Nussbaumer Knaflic</li>
                <li>Directed others with preparation journeys with posts / DMs / Calls</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <footer className="bg-gray-900 text-white py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-8">Let's Connect</h2>
          <div className="flex justify-center gap-8 mb-8">
            <a href="https://github.com/gangaram-vikram" target="_blank" rel="noopener noreferrer" className="hover:text-blue-300 transition-colors">
              <Github size={32} />
            </a>
            <a href="https://linkedin.com/in/vikram" target="_blank" rel="noopener noreferrer" className="hover:text-blue-300 transition-colors">
              <Linkedin size={32} />
            </a>
            <a href="mailto:gangaramvikramvicky@gmail.com" className="hover:text-blue-300 transition-colors">
              <Mail size={32} />
            </a>
          </div>
          <p className="text-gray-400">© 2024 Vikram G. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;